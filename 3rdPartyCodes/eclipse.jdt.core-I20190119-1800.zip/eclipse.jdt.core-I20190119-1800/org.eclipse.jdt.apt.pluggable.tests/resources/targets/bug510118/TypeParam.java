package targets.bug510118;

public class TypeParam {}

