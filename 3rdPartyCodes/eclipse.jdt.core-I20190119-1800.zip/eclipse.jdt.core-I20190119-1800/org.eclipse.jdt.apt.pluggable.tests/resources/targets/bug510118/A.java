package targets.bug510118;

@Annotation510118
public class A implements I<TypeParam>{}
