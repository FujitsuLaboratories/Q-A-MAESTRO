package targets.bug468893;
import targets.bug468893.Annotation;

@Annotation
public class Annotated {
}