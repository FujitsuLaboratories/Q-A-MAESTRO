package targets.bug419769;

import gen.GeneratedClass;

public class InheritedClass extends GeneratedClass {

}
