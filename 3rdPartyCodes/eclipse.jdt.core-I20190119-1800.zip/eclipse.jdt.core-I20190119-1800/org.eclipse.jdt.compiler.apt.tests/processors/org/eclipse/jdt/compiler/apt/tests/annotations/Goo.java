package org.eclipse.jdt.compiler.apt.tests.annotations;

public @interface Goo {

}