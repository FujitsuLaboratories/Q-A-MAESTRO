package targets.bug510118;
import java.lang.annotation.Inherited;

@Inherited
public @interface Annotation510118 {
}