package targets.bug510118;

public interface I <T extends Object> {}
